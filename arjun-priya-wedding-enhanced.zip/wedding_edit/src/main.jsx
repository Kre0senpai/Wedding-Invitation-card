import React, { useEffect, useMemo, useState, useCallback } from "react";
import { createRoot } from "react-dom/client";
import { motion, AnimatePresence } from "framer-motion";
import {
  ChevronLeft, ChevronRight, Gift, Heart, MapPin, Send, Sparkles,
} from "lucide-react";
import "./styles.css";

/* ==========================================================================
   WEDDING DATA — edit these to update the whole site
   ========================================================================== */

const COUPLE = {
  groomFirst: "Arjun",
  groomFull: "Arjun Mehta",
  groomRole: "ELDEST SON",
  brideFirst: "Priya",
  brideFull: "Priya Sharma",
  brideRole: "YOUNGEST DAUGHTER",
};

const FAMILIES = [
  {
    label: "Mr. & Mrs.",
    names: ["Rajiv Mehta", "Anjali Mehta"],
    address: "18 Civil Lines, Ashok Marg,\nJaipur, Rajasthan 302006",
  },
  {
    label: "Mr. & Mrs.",
    names: ["Vikram Sharma", "Sunita Sharma"],
    address: "7 Amer Road, Brahmpuri,\nJaipur, Rajasthan 302002",
  },
];

const CEREMONY = {
  venueLine1: "THE WEDDING CEREMONY WILL BE HELD AT",
  venueLine2: "THE FAMILY HOME",
  time: "10:30",
  weekday: "SATURDAY",
  day: "05",
  month: "DECEMBER",
  year: "2026",
};

const RECEPTION = {
  time: "19:00",
  welcome: "18:00",
  reception: "19:00",
  venueName: "Rambagh Palace, Jaipur",
  venueAddress: "Rambagh Palace, Bhawani Singh Road, Jaipur, Rajasthan 302005, India",
  mapQuery: "Rambagh Palace Bhawani Singh Road Jaipur Rajasthan",
};

// Countdown targets the reception (matches the times shown throughout the invite)
const WEDDING_DATE = new Date("2026-12-05T19:00:00+05:30");
const WEDDING_DATE_DISPLAY = "December 05, 2026";

const DRESS_CODE = {
  title: "Party Attire",
  swatches: ["#7a1620", "#c9a36b", "#fdf7ea"],
};

const SCHEDULE = [
  { time: "18:00", label: "Welcome guests" },
  { time: "19:00", label: "Ceremony begins" },
  { time: "19:20", label: "Champagne and cake" },
  { time: "19:45", label: "Main course served" },
  { time: "21:30", label: "Celebration ends" },
];

const GALLERY_PLACEHOLDERS = [
  { id: 1, label: "The Proposal", color: "#7a1620" },
  { id: 2, label: "Engagement Day", color: "#9c7a45" },
  { id: 3, label: "First Trip Together", color: "#5c0f19" },
  { id: 4, label: "Family Gathering", color: "#c9a36b" },
  { id: 5, label: "Mehndi Preview", color: "#8a2035" },
  { id: 6, label: "Save The Date Shoot", color: "#7a5a2e" },
];

const SEED_MESSAGES = [
  { name: "Rohan Kapoor", time: "8/29/2026, 11:39:15 AM", text: "Congratulations Arjun and Priya! Wishing you a lifetime of love and laughter." },
  { name: "Meera Iyer", time: "8/29/2026, 11:39:15 AM", text: "What a beautiful invitation. So happy for you both, see you in Jaipur!" },
  { name: "Daniel Whitfield", time: "8/29/2026, 11:39:15 AM", text: "Wishing you every happiness as you begin this new chapter together." },
  { name: "Ananya Rao", time: "8/29/2026, 11:39:15 AM", text: "Congratulations! May your home always be full of warmth and joy." },
  { name: "Sameer Gupta", time: "8/29/2026, 11:39:15 AM", text: "So thrilled for you two. Here's to a wonderful life together!" },
];

/* ==========================================================================
   HOOKS
   ========================================================================== */

function useCountdown(target) {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  const diff = Math.max(0, target - now);
  return {
    days: Math.floor(diff / 86400000),
    hours: Math.floor((diff / 3600000) % 24),
    minutes: Math.floor((diff / 60000) % 60),
    seconds: Math.floor((diff / 1000) % 60),
  };
}

/* ==========================================================================
   DECORATIVE SVG COMPONENTS
   ========================================================================== */

function OrnateCornerSVG({ className = "" }) {
  return (
    <svg className={`corner-ornament ${className}`} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M 4 4 H 96 M 4 4 V 96" stroke="#c9a36b" strokeWidth="2.2" />
      <path d="M 13 13 H 78 M 13 13 V 78" stroke="#9c7a45" strokeWidth="1" strokeDasharray="3 2" />
      <path d="M 4 44 C 24 44 44 24 44 4" stroke="#c9a36b" strokeWidth="1.4" fill="none" />
      <circle cx="18" cy="18" r="3.5" fill="#c9a36b" />
      <circle cx="30" cy="12" r="2" fill="#9c7a45" />
      <circle cx="12" cy="30" r="2" fill="#9c7a45" />
    </svg>
  );
}

function BougainvilleaSpraySVG({ className = "", size = 130 }) {
  return (
    <svg className={`floral-spray ${className}`} width={size} height={size * 1.05} viewBox="0 0 220 230" fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="leafGrad2" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#3d6b38" /><stop offset="100%" stopColor="#1e3b1a" />
        </linearGradient>
        <radialGradient id="pinkFlower2" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#ff4d8d" /><stop offset="60%" stopColor="#d91458" /><stop offset="100%" stopColor="#7a0022" />
        </radialGradient>
        <radialGradient id="deepFlower2" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#ff70a6" /><stop offset="70%" stopColor="#c20d49" /><stop offset="100%" stopColor="#5c001a" />
        </radialGradient>
      </defs>
      <path d="M 218 2 C 175 22 140 62 118 118 C 102 158 78 192 30 224" stroke="#3d2817" strokeWidth="3" strokeLinecap="round" />
      <path d="M 210 35 C 178 58 155 96 140 146 C 130 176 112 206 84 224" stroke="#3d2817" strokeWidth="2" strokeLinecap="round" />
      <path d="M 160 42 C 140 32 135 52 150 62 C 165 57 165 47 160 42 Z" fill="url(#leafGrad2)" />
      <path d="M 125 96 C 105 86 100 106 115 116 C 130 111 130 101 125 96 Z" fill="url(#leafGrad2)" />
      <path d="M 92 150 C 72 140 67 160 82 170 C 97 165 97 155 92 150 Z" fill="url(#leafGrad2)" />
      <g opacity="0.95">
        <circle cx="188" cy="18" r="14" fill="url(#pinkFlower2)" />
        <circle cx="202" cy="33" r="12" fill="url(#deepFlower2)" />
        <circle cx="172" cy="33" r="11" fill="url(#pinkFlower2)" />
        <circle cx="188" cy="48" r="13" fill="url(#deepFlower2)" />
        <circle cx="148" cy="72" r="13" fill="url(#pinkFlower2)" />
        <circle cx="162" cy="88" r="12" fill="url(#deepFlower2)" />
        <circle cx="132" cy="92" r="11" fill="url(#pinkFlower2)" />
        <circle cx="112" cy="138" r="12" fill="url(#pinkFlower2)" />
        <circle cx="98" cy="158" r="10" fill="url(#deepFlower2)" />
        <circle cx="66" cy="198" r="10" fill="url(#pinkFlower2)" />
        <circle cx="40" cy="222" r="8" fill="url(#deepFlower2)" />
      </g>
    </svg>
  );
}

function HangingBellsSVG() {
  return (
    <svg className="hero-bells" width="70" height="130" viewBox="0 0 85 170" fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="bellGold2" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#fceabb" /><stop offset="50%" stopColor="#c9a36b" /><stop offset="100%" stopColor="#875e29" />
        </linearGradient>
      </defs>
      <line x1="22" y1="0" x2="22" y2="70" stroke="#c9a36b" strokeWidth="1.5" strokeDasharray="3 3" />
      <circle cx="22" cy="22" r="3" fill="url(#bellGold2)" />
      <circle cx="22" cy="46" r="4" fill="url(#bellGold2)" />
      <path d="M 22 70 C 13 70 10 84 8 92 H 36 C 34 84 31 70 22 70 Z" fill="url(#bellGold2)" />
      <rect x="7" y="92" width="30" height="4" rx="2" fill="#875e29" />
      <circle cx="22" cy="100" r="3.5" fill="url(#bellGold2)" />
    </svg>
  );
}

function GaneshaIconSVG({ size = 46 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="ganeshaGold2" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#f7e096" /><stop offset="40%" stopColor="#c9a36b" /><stop offset="100%" stopColor="#875e29" />
        </linearGradient>
      </defs>
      <path d="M 50 6 L 42 22 H 58 Z" fill="url(#ganeshaGold2)" stroke="#875e29" strokeWidth="1" />
      <circle cx="50" cy="11" r="2.5" fill="#7a1620" />
      <path d="M 30 28 C 16 22 14 42 32 44 C 36 52 42 56 45 62 C 47 68 43 74 50 74 C 57 74 61 68 56 62 C 53 58 51 52 51 44 C 69 42 70 22 56 28" stroke="url(#ganeshaGold2)" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round" fill="none" />
      <path d="M 47 44 C 44 54 43 68 52 70 C 58 71 61 65 57 61 C 54 57 48 60 50 64" stroke="url(#ganeshaGold2)" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round" fill="none" />
      <path d="M 44 26 Q 50 23 56 26 M 45 30 Q 50 28 55 30 M 47 34 Q 50 33 53 34" stroke="#7a1620" strokeWidth="2" strokeLinecap="round" />
      <circle cx="50" cy="21" r="2" fill="#7a1620" />
    </svg>
  );
}

function MiniDividerSVG() {
  return (
    <svg className="mini-divider" width="180" height="24" viewBox="0 0 200 28" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M 10 14 H 75 M 125 14 H 190" stroke="#c9a36b" strokeWidth="1.2" />
      <circle cx="75" cy="14" r="3" fill="#c9a36b" />
      <circle cx="125" cy="14" r="3" fill="#c9a36b" />
      <path d="M 100 3 L 107 14 L 100 25 L 93 14 Z" fill="#c9a36b" />
      <path d="M 100 7 C 88 7 80 14 80 14 C 80 14 88 21 100 21 C 112 21 120 14 120 14 C 120 14 112 7 100 7 Z" stroke="#9c7a45" strokeWidth="1" fill="none" />
    </svg>
  );
}

function MonumentSilhouetteSVG({ opacity = 1 }) {
  return (
    <svg className="hero-monument-svg" viewBox="0 0 400 180" preserveAspectRatio="xMidYMax slice" style={{ opacity }}>
      <defs>
        <linearGradient id="waterGrad" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#e5c158" /><stop offset="100%" stopColor="#c9a36b" />
        </linearGradient>
      </defs>
      <rect x="0" y="130" width="400" height="50" fill="url(#waterGrad)" opacity="0.5" />
      {/* left palace cluster */}
      <g fill="#9c7a45" opacity="0.85">
        <rect x="0" y="90" width="60" height="60" />
        <rect x="55" y="75" width="30" height="75" />
        <circle cx="70" cy="72" r="12" />
        <rect x="15" y="70" width="18" height="30" />
        <circle cx="24" cy="66" r="9" />
      </g>
      {/* right chhatri */}
      <g fill="#9c7a45" opacity="0.85">
        <rect x="330" y="95" width="14" height="55" />
        <rect x="365" y="95" width="14" height="55" />
        <rect x="325" y="90" width="60" height="8" />
        <path d="M 320 90 C 320 60 390 60 390 90 Z" />
        <circle cx="355" cy="55" r="7" />
      </g>
      <rect x="0" y="148" width="400" height="4" fill="#875e29" opacity="0.6" />
    </svg>
  );
}

/* ==========================================================================
   ICS CALENDAR FILE HELPER
   ========================================================================== */

function buildIcsHref() {
  const dt = "20261205T190000";
  const dtEnd = "20261205T230000";
  const ics = [
    "BEGIN:VCALENDAR", "VERSION:2.0", "BEGIN:VEVENT",
    `DTSTART:${dt}`, `DTEND:${dtEnd}`,
    "SUMMARY:Arjun & Priya's Wedding",
    `LOCATION:${RECEPTION.venueAddress}`,
    "DESCRIPTION:Wedding reception of Arjun Mehta and Priya Sharma",
    "END:VEVENT", "END:VCALENDAR",
  ].join("\r\n");
  return `data:text/calendar;charset=utf-8,${encodeURIComponent(ics)}`;
}

/* ==========================================================================
   SECTION 1 — HERO
   ========================================================================== */

function HeroSection() {
  return (
    <section className="hero-section">
      <div className="hero-art-wrap">
        <img className="hero-art-img" src="/images/hero-arch.png" alt="" />
        <div className="hero-names-overlay">
          <p className="hero-names-script">
            {COUPLE.groomFirst}<br />&<br />{COUPLE.brideFirst}
          </p>
          <p className="hero-date-overlay">{WEDDING_DATE_DISPLAY}</p>
        </div>
        <div className="hero-scroll-cue" aria-hidden="true">
          Explore the invitation
          <span />
        </div>
      </div>
    </section>
  );
}

/* ==========================================================================
   SECTION 2 — CEREMONY INFO
   ========================================================================== */

function CeremonyInfoSection() {
  return (
    <section className="section">
      <OrnateCornerSVG className="corner-tl" />
      <OrnateCornerSVG className="corner-tr" />
      <OrnateCornerSVG className="corner-bl" />
      <OrnateCornerSVG className="corner-br" />
      <BougainvilleaSpraySVG className="floral-bl" size={100} />
      <div className="content-max">
        <MiniDividerSVG />
        <p className="section-eyebrow">Ceremony Info</p>

        <div className="families-row">
          {FAMILIES.map((fam, i) => (
            <div className="family-col" key={i}>
              <p className="family-label">{fam.label}</p>
              <p className="family-names">
                {fam.names.map((n, j) => <React.Fragment key={j}>{n}<br /></React.Fragment>)}
              </p>
              <p className="family-address">
                {fam.address.split("\n").map((l, j) => <React.Fragment key={j}>{l}<br /></React.Fragment>)}
              </p>
            </div>
          ))}
        </div>

        <p className="announce-line">We joyfully announce<br />the wedding of our children</p>

        <div className="couple-block">
          <h1 className="couple-first-name">{COUPLE.groomFull}</h1>
          <p className="couple-role">{COUPLE.groomRole}</p>
        </div>
        <div className="couple-amp">&amp;</div>
        <div className="couple-block">
          <h1 className="couple-first-name">{COUPLE.brideFull}</h1>
          <p className="couple-role">{COUPLE.brideRole}</p>
        </div>

        <p className="venue-note">
          {CEREMONY.venueLine1}<br />{CEREMONY.venueLine2}
        </p>
        <p className="venue-note" style={{ marginTop: -14 }}>AT {CEREMONY.time}</p>

        <div className="date-badge-row">
          <span className="date-badge-label">{CEREMONY.weekday}</span>
          <span className="date-badge-day">{CEREMONY.day}</span>
          <span className="date-badge-label">{CEREMONY.month}</span>
        </div>
        <p className="date-badge-year">{CEREMONY.year}</p>
      </div>
    </section>
  );
}

/* ==========================================================================
   SECTION 3 — PHOTO GALLERY (3D COVERFLOW)
   ========================================================================== */

function PhotoGallerySection() {
  const [index, setIndex] = useState(0);
  const total = GALLERY_PLACEHOLDERS.length;

  const go = useCallback((dir) => {
    setIndex((i) => (i + dir + total) % total);
  }, [total]);

  return (
    <section className="section">
      <OrnateCornerSVG className="corner-tl" />
      <OrnateCornerSVG className="corner-tr" />
      
      <div className="content-max">
      <p className="section-eyebrow">Photo Gallery</p>

      <div className="gallery-viewport">
        <button className="gallery-nav-btn gallery-nav-prev" onClick={() => go(-1)} aria-label="Previous photo">
          <ChevronLeft size={18} />
        </button>
        <div className="gallery-track">
          {GALLERY_PLACEHOLDERS.map((photo, i) => {
            let offset = i - index;
            if (offset > total / 2) offset -= total;
            if (offset < -total / 2) offset += total;
            const abs = Math.abs(offset);
            if (abs > 2) return null;
            const translateX = offset * 95;
            const scale = abs === 0 ? 1 : abs === 1 ? 0.82 : 0.66;
            const rotateY = offset * -22;
            const zIndex = 10 - abs;
            const opacity = abs > 2 ? 0 : 1 - abs * 0.28;
            return (
              <div
                key={photo.id}
                className="gallery-card"
                style={{
                  background: `linear-gradient(160deg, ${photo.color}, #2a1810)`,
                  transform: `translate(-50%, -50%) translateX(${translateX}px) scale(${scale}) rotateY(${rotateY}deg)`,
                  zIndex, opacity,
                }}
              >
                <span>{photo.label}</span>
              </div>
            );
          })}
        </div>
        <button className="gallery-nav-btn gallery-nav-next" onClick={() => go(1)} aria-label="Next photo">
          <ChevronRight size={18} />
        </button>
      </div>
      <p className="gallery-counter">{index + 1} / {total}</p>

      <MiniDividerSVG />
    
      </div></section>
  );
}

/* ==========================================================================
   SECTION 4 — RECEPTION INFO
   ========================================================================== */

function ReceptionInfoSection() {
  const cd = useCountdown(WEDDING_DATE);
  return (
    <section className="section">
      <BougainvilleaSpraySVG className="floral-br" size={110} />
      
      <div className="content-max">
      <p className="section-eyebrow">Reception Info</p>
      <p style={{ fontSize: 12, letterSpacing: "0.1em", color: "var(--muted)", textTransform: "uppercase" }}>
        The reception will take place at:
      </p>
      <p className="reception-time-big">{RECEPTION.time}</p>

      <div className="date-badge-row">
        <span className="date-badge-label">{CEREMONY.weekday}</span>
        <span className="date-badge-day">{CEREMONY.day}</span>
        <span className="date-badge-label">{CEREMONY.month}</span>
      </div>
      <p className="date-badge-year" style={{ marginBottom: 24 }}>{CEREMONY.year}</p>

      <div className="welcome-reception-row">
        <div className="wr-item">
          <p className="wr-label">Welcome</p>
          <p className="wr-value">{RECEPTION.welcome}</p>
        </div>
        <div className="wr-item">
          <p className="wr-label">Reception</p>
          <p className="wr-value">{RECEPTION.reception}</p>
        </div>
      </div>

      <p className="countdown-title">Counting down to our celebration</p>
      <div className="countdown-value" aria-label="Wedding countdown">
        {[
          [cd.days, "Days"],
          [cd.hours, "Hours"],
          [cd.minutes, "Minutes"],
          [cd.seconds, "Seconds"],
        ].map(([value, label]) => (
          <div className="countdown-unit" key={label}>
            <strong>{String(value).padStart(2, "0")}</strong>
            <span>{label}</span>
          </div>
        ))}
      </div>
      </div>
    </section>
  );
}

/* ==========================================================================
   SECTION 5 — CALENDAR + VENUE MAP
   ========================================================================== */

function buildDecember2026Grid() {
  const year = 2026, month = 11; // December (0-indexed)
  const first = new Date(year, month, 1);
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  // Monday-first index: JS getDay() 0=Sun..6=Sat -> convert to 0=Mon..6=Sun
  const firstWeekday = (first.getDay() + 6) % 7;
  const cells = Array(firstWeekday).fill(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);
  return cells;
}

function CalendarMapSection() {
  const cells = useMemo(buildDecember2026Grid, []);
  return (
    <section className="section">
      
      <div className="content-max">
      <div className="calendar-frame">
        <OrnateCornerSVG className="corner-tl" style={{ width: 30, height: 30, top: -6, left: -6 }} />
        <p className="calendar-month-title">December 2026</p>
        <div className="calendar-weekdays">
          {["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"].map((d) => <span key={d}>{d}</span>)}
        </div>
        <div className="calendar-days">
          {cells.map((d, i) =>
            d === null
              ? <span className="blank" key={i}>0</span>
              : <span key={i} className={d === 5 ? "cal-highlight" : ""}>
                  {d === 5 ? <><Heart size={11} fill="currentColor" />{d}</> : d}
                </span>
          )}
        </div>
      </div>

      <a className="add-calendar-link" href={buildIcsHref()} download="arjun-priya-wedding.ics">
        Add to Calendar
      </a>
      <br />
      <button className="primary-pill-btn" onClick={() => alert("Thank you! Your attendance has been noted.")}>
        Confirm Attendance
      </button>

      <p className="venue-heading">Wedding Reception Venue</p>
      <p className="venue-address">{RECEPTION.venueAddress}</p>
      <div className="map-frame">
        <iframe
          title={RECEPTION.venueName}
          src={`https://maps.google.com/maps?q=${encodeURIComponent(RECEPTION.mapQuery)}&output=embed&z=15`}
          width="100%" height="100%" style={{ border: 0 }}
          loading="lazy" referrerPolicy="no-referrer-when-downgrade"
        />
      </div>
      <a
        className="map-directions-link"
        target="_blank" rel="noreferrer"
        href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(RECEPTION.mapQuery)}`}
      >
        <MapPin size={13} /> Get Directions
      </a>

      <MiniDividerSVG />
      </div>
    </section>
  );
}

/* ==========================================================================
   SECTION 6 — DRESS CODE + SCHEDULE
   ========================================================================== */

function DressAndScheduleSection() {
  return (
    <section className="section">
      <p className="section-eyebrow">Dress Code</p>
      <p className="dress-subtitle">{DRESS_CODE.title}</p>
      <div className="swatch-row">
        {DRESS_CODE.swatches.map((c, i) => (
          <span className="swatch" style={{ background: c }} key={i} />
        ))}
      </div>

      <div style={{ height: 40 }} />
      <p className="section-eyebrow">Wedding Day Schedule</p>
      <div className="schedule-list">
        {SCHEDULE.map((item, i) => (
          <div className="schedule-row" key={i}>
            <span className="schedule-time">{item.time}</span>
            <span className="schedule-dot-wrap"><span className="schedule-dot" /></span>
            <span className="schedule-label">{item.label}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ==========================================================================
   SECTION 7 — GUESTBOOK
   ========================================================================== */

function GuestbookSection() {
  const [name, setName] = useState("");
  const [wish, setWish] = useState("");
  const [messages, setMessages] = useState(SEED_MESSAGES);

  function handleSubmit(e) {
    e.preventDefault();
    if (!name.trim() || !wish.trim()) return;
    const now = new Date();
    const time = now.toLocaleString("en-US", {
      month: "numeric", day: "numeric", year: "numeric",
      hour: "numeric", minute: "2-digit", second: "2-digit", hour12: true,
    });
    setMessages((m) => [{ name: name.trim(), time, text: wish.trim() }, ...m]);
    setName(""); setWish("");
  }

  return (
    <section className="section">
      <BougainvilleaSpraySVG className="floral-tr" size={110} />
      <p className="section-eyebrow">Guestbook</p>

      <form className="guest-form" onSubmit={handleSubmit}>
        <input
          type="text" placeholder="Enter your name*"
          value={name} onChange={(e) => setName(e.target.value)}
        />
        <textarea
          placeholder="Enter your wishes*" rows={4}
          value={wish} onChange={(e) => setWish(e.target.value)}
        />
        <div className="guest-form-actions">
          <button className="primary-pill-btn" type="submit" style={{ marginBottom: 0 }}>
            <Send size={13} style={{ marginRight: 6, verticalAlign: -2 }} />Send Wishes
          </button>
        </div>
      </form>

      <div className="guest-messages">
        {messages.map((m, i) => (
          <div className="guest-msg-card" key={i}>
            <div className="guest-msg-top">
              <span className="guest-msg-name">{m.name}</span>
              <span className="guest-msg-time">{m.time}</span>
            </div>
            <p className="guest-msg-body">{m.text}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ==========================================================================
   SECTION 8 — GIFT BOX
   ========================================================================== */

function GiftBoxSection() {
  const [opened, setOpened] = useState(false);
  return (
    <section className="section">
      <p className="section-eyebrow">Gift Box</p>
      <div className="gift-box-wrap">
        <motion.div
          className="gift-box-emoji-wrap"
          onClick={() => setOpened(true)}
          whileTap={{ scale: 0.92 }}
          animate={opened ? { rotate: [0, -8, 8, -4, 0], scale: [1, 1.12, 1] } : {}}
          transition={{ duration: 0.6 }}
        >
          <Gift size={72} color="#7a1620" strokeWidth={1.3} />
        </motion.div>
        {!opened && <p className="gift-tap-label">Tap to open</p>}
        {opened && (
          <motion.p
            className="gift-message"
            initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
          >
            <Heart size={14} fill="#7a1620" style={{ verticalAlign: -2, marginRight: 4 }} />
            Your presence would be the greatest gift we could receive!
          </motion.p>
        )}
      </div>
    </section>
  );
}

/* ==========================================================================
   FOOTER
   ========================================================================== */

function FooterSection() {
  return (
    <footer className="footer-section">
      <div className="footer-monument-bg"><MonumentSilhouetteSVG opacity={0.5} /></div>
      <Sparkles size={20} color="#c9a36b" style={{ marginBottom: 10 }} />
      <h2 className="footer-couple-title">{COUPLE.groomFirst} &amp; {COUPLE.brideFirst}</h2>
      <p className="footer-sub">We can't wait to celebrate with you</p>
    </footer>
  );
}

/* ==========================================================================
   OPENING GATE (FULL-SCREEN COVER CARD)
   ========================================================================== */

function GateSparkles() {
  const dots = useMemo(() => Array.from({ length: 14 }, (_, i) => ({
    id: i,
    top: `${(i * 37 + 6) % 96}%`,
    left: `${(i * 53 + 4) % 96}%`,
    size: 6 + (i % 4) * 3,
    delay: `${(i % 6) * 0.4}s`,
  })), []);
  return (
    <div className="gate-sparkles" aria-hidden="true">
      {dots.map((d) => (
        <Sparkles
          key={d.id}
          size={d.size}
          className="gate-sparkle"
          style={{ top: d.top, left: d.left, animationDelay: d.delay }}
        />
      ))}
    </div>
  );
}

function GateScreen({ onOpen }) {
  return (
    <motion.div
      className="gate-screen"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.06 }}
      transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
    >
      <GateSparkles />
      <motion.div
        className="gate-card"
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
      >
        <BougainvilleaSpraySVG className="floral-tl" size={140} />
        <BougainvilleaSpraySVG className="floral-br" size={140} />

        <div className="gate-heart-seal"><Heart size={20} fill="#fdf7ea" color="#fdf7ea" /></div>

        <p className="gate-names-script">
          {COUPLE.groomFirst}<br />&<br />{COUPLE.brideFirst}
        </p>

        <MiniDividerSVG />

        <p className="gate-date-line">{WEDDING_DATE_DISPLAY}</p>
        <p className="gate-invite-line">Cordially Invites</p>

        <motion.button
          className="gate-open-btn"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.94 }}
          onClick={onOpen}
        >
          Open
        </motion.button>
      </motion.div>
    </motion.div>
  );
}

/* ==========================================================================
   APP
   ========================================================================== */

function App() {
  const [opened, setOpened] = useState(false);

  return (
    <>
      <AnimatePresence>
        {!opened && <GateScreen key="gate" onOpen={() => setOpened(true)} />}
      </AnimatePresence>

      {opened && (
        <div className="page-shell">
          <HeroSection />
          <CeremonyInfoSection />
          <PhotoGallerySection />
          <ReceptionInfoSection />
          <CalendarMapSection />
          <DressAndScheduleSection />
          <GuestbookSection />
          <GiftBoxSection />
          <FooterSection />
        </div>
      )}
    </>
  );
}

createRoot(document.getElementById("root")).render(<App />);
